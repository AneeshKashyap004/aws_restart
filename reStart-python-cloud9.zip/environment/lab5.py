myMixedTypeList = [45, 28903, 1.02, True, "Im a human.", "45"]

for item in myMixedTypeList:
    print(" {} is of the data type {}".format(item,type(item)))