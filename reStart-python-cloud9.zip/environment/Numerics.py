print("Python has three numeric types: int, float, and complex")

myvalue=1
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the datatype " + str(type(myvalue)))

myvalue=3.8
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the datatype " + str(type(myvalue)))

myvalue=5j
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the datatype " + str(type(myvalue)))

myvalue=True
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the datatype " + str(type(myvalue)))

myvalue=False
print(myvalue)
print(type(myvalue))
print(str(myvalue) + " is the datatype " + str(type(myvalue)))

i = 1
while i <= 10:
    print (i * '*')
    i = i + 1 

i = 0
while i < 10:
    i += 1
    if i % 2 == 0:  # Skip even numbers
        continue
    print(i)